﻿
namespace keshe
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.借书证管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.办理借书证ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.借书证信息修改ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图书管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新书入库ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图书维护ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.借阅管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.借阅信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.读者类别管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加读者类别ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.读者类别维护ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.权限管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.借阅ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.借书ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.续借ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.还书ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.密码修改ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.操作ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.提交全部操作ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.放弃全部操作ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.联系管理员ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.dgv_Actions = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.提交操作ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.放弃ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Actions)).BeginInit();
            this.contextMenuStrip.SuspendLayout();
            this.tableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.借书证管理ToolStripMenuItem,
            this.图书管理ToolStripMenuItem,
            this.借阅管理ToolStripMenuItem,
            this.系统管理ToolStripMenuItem,
            this.借阅ToolStripMenuItem,
            this.用户ToolStripMenuItem,
            this.操作ToolStripMenuItem,
            this.联系管理员ToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(847, 28);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip";
            // 
            // 借书证管理ToolStripMenuItem
            // 
            this.借书证管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.办理借书证ToolStripMenuItem,
            this.借书证信息修改ToolStripMenuItem});
            this.借书证管理ToolStripMenuItem.Name = "借书证管理ToolStripMenuItem";
            this.借书证管理ToolStripMenuItem.Size = new System.Drawing.Size(97, 24);
            this.借书证管理ToolStripMenuItem.Text = "借书证管理";
            this.借书证管理ToolStripMenuItem.Visible = false;
            // 
            // 办理借书证ToolStripMenuItem
            // 
            this.办理借书证ToolStripMenuItem.Name = "办理借书证ToolStripMenuItem";
            this.办理借书证ToolStripMenuItem.Size = new System.Drawing.Size(247, 26);
            this.办理借书证ToolStripMenuItem.Text = "办理借书证[TODO]";
            // 
            // 借书证信息修改ToolStripMenuItem
            // 
            this.借书证信息修改ToolStripMenuItem.Name = "借书证信息修改ToolStripMenuItem";
            this.借书证信息修改ToolStripMenuItem.Size = new System.Drawing.Size(247, 26);
            this.借书证信息修改ToolStripMenuItem.Text = "借书证信息修改[TODO]";
            // 
            // 图书管理ToolStripMenuItem
            // 
            this.图书管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新书入库ToolStripMenuItem,
            this.图书维护ToolStripMenuItem});
            this.图书管理ToolStripMenuItem.Name = "图书管理ToolStripMenuItem";
            this.图书管理ToolStripMenuItem.Size = new System.Drawing.Size(82, 24);
            this.图书管理ToolStripMenuItem.Text = "图书管理";
            this.图书管理ToolStripMenuItem.Visible = false;
            this.图书管理ToolStripMenuItem.Click += new System.EventHandler(this.图书管理ToolStripMenuItem_Click);
            // 
            // 新书入库ToolStripMenuItem
            // 
            this.新书入库ToolStripMenuItem.Name = "新书入库ToolStripMenuItem";
            this.新书入库ToolStripMenuItem.Size = new System.Drawing.Size(150, 26);
            this.新书入库ToolStripMenuItem.Text = "新书入库";
            this.新书入库ToolStripMenuItem.Click += new System.EventHandler(this.新书入库ToolStripMenuItem_Click);
            // 
            // 图书维护ToolStripMenuItem
            // 
            this.图书维护ToolStripMenuItem.Name = "图书维护ToolStripMenuItem";
            this.图书维护ToolStripMenuItem.Size = new System.Drawing.Size(150, 26);
            this.图书维护ToolStripMenuItem.Text = "图书维护";
            this.图书维护ToolStripMenuItem.Click += new System.EventHandler(this.图书维护ToolStripMenuItem_Click);
            // 
            // 借阅管理ToolStripMenuItem
            // 
            this.借阅管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.借阅信息ToolStripMenuItem});
            this.借阅管理ToolStripMenuItem.Name = "借阅管理ToolStripMenuItem";
            this.借阅管理ToolStripMenuItem.Size = new System.Drawing.Size(82, 24);
            this.借阅管理ToolStripMenuItem.Text = "借阅管理";
            this.借阅管理ToolStripMenuItem.Visible = false;
            this.借阅管理ToolStripMenuItem.Click += new System.EventHandler(this.借阅管理ToolStripMenuItem_Click);
            // 
            // 借阅信息ToolStripMenuItem
            // 
            this.借阅信息ToolStripMenuItem.Name = "借阅信息ToolStripMenuItem";
            this.借阅信息ToolStripMenuItem.Size = new System.Drawing.Size(232, 26);
            this.借阅信息ToolStripMenuItem.Text = "借阅信息管理[TODO]";
            // 
            // 系统管理ToolStripMenuItem
            // 
            this.系统管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.读者类别管理ToolStripMenuItem,
            this.权限管理ToolStripMenuItem});
            this.系统管理ToolStripMenuItem.Name = "系统管理ToolStripMenuItem";
            this.系统管理ToolStripMenuItem.Size = new System.Drawing.Size(82, 24);
            this.系统管理ToolStripMenuItem.Text = "系统管理";
            this.系统管理ToolStripMenuItem.Visible = false;
            // 
            // 读者类别管理ToolStripMenuItem
            // 
            this.读者类别管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加读者类别ToolStripMenuItem,
            this.读者类别维护ToolStripMenuItem});
            this.读者类别管理ToolStripMenuItem.Name = "读者类别管理ToolStripMenuItem";
            this.读者类别管理ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.读者类别管理ToolStripMenuItem.Text = "读者类别管理";
            // 
            // 添加读者类别ToolStripMenuItem
            // 
            this.添加读者类别ToolStripMenuItem.Name = "添加读者类别ToolStripMenuItem";
            this.添加读者类别ToolStripMenuItem.Size = new System.Drawing.Size(232, 26);
            this.添加读者类别ToolStripMenuItem.Text = "添加读者类别[TODO]";
            // 
            // 读者类别维护ToolStripMenuItem
            // 
            this.读者类别维护ToolStripMenuItem.Name = "读者类别维护ToolStripMenuItem";
            this.读者类别维护ToolStripMenuItem.Size = new System.Drawing.Size(232, 26);
            this.读者类别维护ToolStripMenuItem.Text = "读者类别维护[TODO]";
            // 
            // 权限管理ToolStripMenuItem
            // 
            this.权限管理ToolStripMenuItem.Name = "权限管理ToolStripMenuItem";
            this.权限管理ToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.权限管理ToolStripMenuItem.Text = "权限管理";
            this.权限管理ToolStripMenuItem.Click += new System.EventHandler(this.权限管理ToolStripMenuItem_Click);
            // 
            // 借阅ToolStripMenuItem
            // 
            this.借阅ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.借书ToolStripMenuItem,
            this.续借ToolStripMenuItem,
            this.还书ToolStripMenuItem});
            this.借阅ToolStripMenuItem.Name = "借阅ToolStripMenuItem";
            this.借阅ToolStripMenuItem.Size = new System.Drawing.Size(52, 24);
            this.借阅ToolStripMenuItem.Text = "借阅";
            // 
            // 借书ToolStripMenuItem
            // 
            this.借书ToolStripMenuItem.Name = "借书ToolStripMenuItem";
            this.借书ToolStripMenuItem.Size = new System.Drawing.Size(120, 26);
            this.借书ToolStripMenuItem.Text = "借书";
            this.借书ToolStripMenuItem.Click += new System.EventHandler(this.借书ToolStripMenuItem_Click);
            // 
            // 续借ToolStripMenuItem
            // 
            this.续借ToolStripMenuItem.Name = "续借ToolStripMenuItem";
            this.续借ToolStripMenuItem.Size = new System.Drawing.Size(120, 26);
            this.续借ToolStripMenuItem.Text = "续借";
            this.续借ToolStripMenuItem.Click += new System.EventHandler(this.续借ToolStripMenuItem_Click);
            // 
            // 还书ToolStripMenuItem
            // 
            this.还书ToolStripMenuItem.Name = "还书ToolStripMenuItem";
            this.还书ToolStripMenuItem.Size = new System.Drawing.Size(120, 26);
            this.还书ToolStripMenuItem.Text = "还书";
            this.还书ToolStripMenuItem.Click += new System.EventHandler(this.还书ToolStripMenuItem_Click);
            // 
            // 用户ToolStripMenuItem
            // 
            this.用户ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.密码修改ToolStripMenuItem});
            this.用户ToolStripMenuItem.Name = "用户ToolStripMenuItem";
            this.用户ToolStripMenuItem.Size = new System.Drawing.Size(52, 24);
            this.用户ToolStripMenuItem.Text = "用户";
            this.用户ToolStripMenuItem.Click += new System.EventHandler(this.用户ToolStripMenuItem_Click);
            // 
            // 密码修改ToolStripMenuItem
            // 
            this.密码修改ToolStripMenuItem.Name = "密码修改ToolStripMenuItem";
            this.密码修改ToolStripMenuItem.Size = new System.Drawing.Size(150, 26);
            this.密码修改ToolStripMenuItem.Text = "密码修改";
            this.密码修改ToolStripMenuItem.Click += new System.EventHandler(this.密码修改ToolStripMenuItem_Click);
            // 
            // 操作ToolStripMenuItem
            // 
            this.操作ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.提交全部操作ToolStripMenuItem,
            this.放弃全部操作ToolStripMenuItem,
            this.关于ToolStripMenuItem,
            this.退出系统ToolStripMenuItem});
            this.操作ToolStripMenuItem.Name = "操作ToolStripMenuItem";
            this.操作ToolStripMenuItem.Size = new System.Drawing.Size(52, 24);
            this.操作ToolStripMenuItem.Text = "操作";
            // 
            // 提交全部操作ToolStripMenuItem
            // 
            this.提交全部操作ToolStripMenuItem.Name = "提交全部操作ToolStripMenuItem";
            this.提交全部操作ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.提交全部操作ToolStripMenuItem.Text = "提交全部操作";
            this.提交全部操作ToolStripMenuItem.Click += new System.EventHandler(this.提交全部操作ToolStripMenuItem_Click);
            // 
            // 放弃全部操作ToolStripMenuItem
            // 
            this.放弃全部操作ToolStripMenuItem.Name = "放弃全部操作ToolStripMenuItem";
            this.放弃全部操作ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.放弃全部操作ToolStripMenuItem.Text = "放弃全部操作";
            this.放弃全部操作ToolStripMenuItem.Click += new System.EventHandler(this.放弃全部操作ToolStripMenuItem_Click);
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.关于ToolStripMenuItem.Text = "关于";
            this.关于ToolStripMenuItem.Click += new System.EventHandler(this.关于ToolStripMenuItem_Click);
            // 
            // 退出系统ToolStripMenuItem
            // 
            this.退出系统ToolStripMenuItem.Name = "退出系统ToolStripMenuItem";
            this.退出系统ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.退出系统ToolStripMenuItem.Text = "退出系统";
            this.退出系统ToolStripMenuItem.Click += new System.EventHandler(this.退出系统ToolStripMenuItem_Click);
            // 
            // 联系管理员ToolStripMenuItem
            // 
            this.联系管理员ToolStripMenuItem.Name = "联系管理员ToolStripMenuItem";
            this.联系管理员ToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.联系管理员ToolStripMenuItem.Text = "联系管理员";
            this.联系管理员ToolStripMenuItem.Click += new System.EventHandler(this.联系管理员ToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 485);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip.Size = new System.Drawing.Size(847, 26);
            this.statusStrip.SizingGrip = false;
            this.statusStrip.TabIndex = 1;
            this.statusStrip.Text = "statusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(96, 20);
            this.toolStripStatusLabel.Text = "[Info] 加载中";
            // 
            // dgv_Actions
            // 
            this.dgv_Actions.AllowUserToAddRows = false;
            this.dgv_Actions.AllowUserToDeleteRows = false;
            this.dgv_Actions.AllowUserToResizeColumns = false;
            this.dgv_Actions.AllowUserToResizeRows = false;
            this.dgv_Actions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Actions.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dgv_Actions.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Actions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgv_Actions.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dgv_Actions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Actions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_Actions.Location = new System.Drawing.Point(2, 2);
            this.dgv_Actions.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_Actions.MultiSelect = false;
            this.dgv_Actions.Name = "dgv_Actions";
            this.dgv_Actions.ReadOnly = true;
            this.dgv_Actions.RowHeadersVisible = false;
            this.dgv_Actions.RowHeadersWidth = 50;
            this.dgv_Actions.RowTemplate.Height = 27;
            this.dgv_Actions.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_Actions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Actions.Size = new System.Drawing.Size(843, 453);
            this.dgv_Actions.TabIndex = 2;
            this.dgv_Actions.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Actions_CellMouseClick);
            this.dgv_Actions.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Actions_CellMouseDoubleClick);
            this.dgv_Actions.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Actions_CellMouseUp);
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.提交操作ToolStripMenuItem1,
            this.放弃ToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(139, 52);
            // 
            // 提交操作ToolStripMenuItem1
            // 
            this.提交操作ToolStripMenuItem1.Name = "提交操作ToolStripMenuItem1";
            this.提交操作ToolStripMenuItem1.Size = new System.Drawing.Size(138, 24);
            this.提交操作ToolStripMenuItem1.Text = "提交操作";
            this.提交操作ToolStripMenuItem1.Click += new System.EventHandler(this.提交操作ToolStripMenuItem1_Click);
            // 
            // 放弃ToolStripMenuItem
            // 
            this.放弃ToolStripMenuItem.Name = "放弃ToolStripMenuItem";
            this.放弃ToolStripMenuItem.Size = new System.Drawing.Size(138, 24);
            this.放弃ToolStripMenuItem.Text = "放弃操作";
            this.放弃ToolStripMenuItem.Click += new System.EventHandler(this.放弃ToolStripMenuItem_Click);
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel.ColumnCount = 1;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel.Controls.Add(this.dgv_Actions, 0, 0);
            this.tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel.Location = new System.Drawing.Point(0, 28);
            this.tableLayoutPanel.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 1;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel.Size = new System.Drawing.Size(847, 457);
            this.tableLayoutPanel.TabIndex = 3;
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(847, 511);
            this.Controls.Add(this.tableLayoutPanel);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.statusStrip);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(865, 558);
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "keshe 图书管理系统";
            this.Load += new System.EventHandler(this.main_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Actions)).EndInit();
            this.contextMenuStrip.ResumeLayout(false);
            this.tableLayoutPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripMenuItem 图书管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新书入库ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图书维护ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借书证管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借阅ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借书ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 续借ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 还书ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 密码修改ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 操作ToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem 退出系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 联系管理员ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_Actions;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem 放弃ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 提交操作ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 提交全部操作ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 放弃全部操作ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系统管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 权限管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 读者类别管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借阅管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借阅信息ToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.ToolStripMenuItem 办理借书证ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借书证信息修改ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加读者类别ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 读者类别维护ToolStripMenuItem;
    }
}