﻿
namespace keshe
{
    partial class changePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(changePassword));
            this.button_OK = new System.Windows.Forms.Button();
            this.textBox_old_pwd = new System.Windows.Forms.TextBox();
            this.label_old_pwd = new System.Windows.Forms.Label();
            this.textBox_new_pwd = new System.Windows.Forms.TextBox();
            this.label_new_pwd = new System.Windows.Forms.Label();
            this.textBox_new_pwd2 = new System.Windows.Forms.TextBox();
            this.label_new_pwd2 = new System.Windows.Forms.Label();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_button = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_old_pwd = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_new_pwd = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_new_pwd2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel_button.SuspendLayout();
            this.tableLayoutPanel_old_pwd.SuspendLayout();
            this.tableLayoutPanel_new_pwd.SuspendLayout();
            this.tableLayoutPanel_new_pwd2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_OK
            // 
            this.button_OK.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_OK.Font = new System.Drawing.Font("字由心雨 常规体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_OK.Location = new System.Drawing.Point(74, 11);
            this.button_OK.Margin = new System.Windows.Forms.Padding(2);
            this.button_OK.Name = "button_OK";
            this.button_OK.Size = new System.Drawing.Size(95, 38);
            this.button_OK.TabIndex = 0;
            this.button_OK.Text = "确认";
            this.button_OK.UseVisualStyleBackColor = true;
            this.button_OK.Click += new System.EventHandler(this.button_OK_Click);
            // 
            // textBox_old_pwd
            // 
            this.textBox_old_pwd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox_old_pwd.Font = new System.Drawing.Font("字由心雨 常规体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_old_pwd.Location = new System.Drawing.Point(147, 11);
            this.textBox_old_pwd.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_old_pwd.Name = "textBox_old_pwd";
            this.textBox_old_pwd.Size = new System.Drawing.Size(269, 35);
            this.textBox_old_pwd.TabIndex = 1;
            this.textBox_old_pwd.UseSystemPasswordChar = true;
            // 
            // label_old_pwd
            // 
            this.label_old_pwd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_old_pwd.AutoSize = true;
            this.label_old_pwd.Font = new System.Drawing.Font("字由心雨 常规体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_old_pwd.Location = new System.Drawing.Point(36, 15);
            this.label_old_pwd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_old_pwd.Name = "label_old_pwd";
            this.label_old_pwd.Size = new System.Drawing.Size(72, 28);
            this.label_old_pwd.TabIndex = 0;
            this.label_old_pwd.Text = "原密码";
            // 
            // textBox_new_pwd
            // 
            this.textBox_new_pwd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox_new_pwd.Font = new System.Drawing.Font("字由心雨 常规体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_new_pwd.Location = new System.Drawing.Point(147, 11);
            this.textBox_new_pwd.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_new_pwd.Name = "textBox_new_pwd";
            this.textBox_new_pwd.Size = new System.Drawing.Size(269, 35);
            this.textBox_new_pwd.TabIndex = 1;
            this.textBox_new_pwd.UseSystemPasswordChar = true;
            // 
            // label_new_pwd
            // 
            this.label_new_pwd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_new_pwd.AutoSize = true;
            this.label_new_pwd.Font = new System.Drawing.Font("字由心雨 常规体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_new_pwd.Location = new System.Drawing.Point(36, 15);
            this.label_new_pwd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_new_pwd.Name = "label_new_pwd";
            this.label_new_pwd.Size = new System.Drawing.Size(72, 28);
            this.label_new_pwd.TabIndex = 0;
            this.label_new_pwd.Text = "新密码";
            // 
            // textBox_new_pwd2
            // 
            this.textBox_new_pwd2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox_new_pwd2.Font = new System.Drawing.Font("字由心雨 常规体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_new_pwd2.Location = new System.Drawing.Point(147, 11);
            this.textBox_new_pwd2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_new_pwd2.Name = "textBox_new_pwd2";
            this.textBox_new_pwd2.Size = new System.Drawing.Size(269, 35);
            this.textBox_new_pwd2.TabIndex = 1;
            this.textBox_new_pwd2.UseSystemPasswordChar = true;
            // 
            // label_new_pwd2
            // 
            this.label_new_pwd2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_new_pwd2.AutoSize = true;
            this.label_new_pwd2.Font = new System.Drawing.Font("字由心雨 常规体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_new_pwd2.Location = new System.Drawing.Point(16, 15);
            this.label_new_pwd2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_new_pwd2.Name = "label_new_pwd2";
            this.label_new_pwd2.Size = new System.Drawing.Size(112, 28);
            this.label_new_pwd2.TabIndex = 0;
            this.label_new_pwd2.Text = "确认新密码";
            // 
            // button_Cancel
            // 
            this.button_Cancel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Font = new System.Drawing.Font("字由心雨 常规体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Cancel.Location = new System.Drawing.Point(317, 11);
            this.button_Cancel.Margin = new System.Windows.Forms.Padding(2);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(95, 38);
            this.button_Cancel.TabIndex = 1;
            this.button_Cancel.Text = "取消";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel_button, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel_old_pwd, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel_new_pwd, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel_new_pwd2, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(494, 266);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // tableLayoutPanel_button
            // 
            this.tableLayoutPanel_button.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel_button.ColumnCount = 2;
            this.tableLayoutPanel_button.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_button.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_button.Controls.Add(this.button_Cancel, 1, 0);
            this.tableLayoutPanel_button.Controls.Add(this.button_OK, 0, 0);
            this.tableLayoutPanel_button.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_button.Location = new System.Drawing.Point(4, 202);
            this.tableLayoutPanel_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanel_button.Name = "tableLayoutPanel_button";
            this.tableLayoutPanel_button.RowCount = 1;
            this.tableLayoutPanel_button.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_button.Size = new System.Drawing.Size(486, 60);
            this.tableLayoutPanel_button.TabIndex = 3;
            // 
            // tableLayoutPanel_old_pwd
            // 
            this.tableLayoutPanel_old_pwd.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel_old_pwd.ColumnCount = 2;
            this.tableLayoutPanel_old_pwd.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_old_pwd.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_old_pwd.Controls.Add(this.textBox_old_pwd, 1, 0);
            this.tableLayoutPanel_old_pwd.Controls.Add(this.label_old_pwd, 0, 0);
            this.tableLayoutPanel_old_pwd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_old_pwd.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel_old_pwd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanel_old_pwd.Name = "tableLayoutPanel_old_pwd";
            this.tableLayoutPanel_old_pwd.RowCount = 1;
            this.tableLayoutPanel_old_pwd.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_old_pwd.Size = new System.Drawing.Size(486, 58);
            this.tableLayoutPanel_old_pwd.TabIndex = 0;
            // 
            // tableLayoutPanel_new_pwd
            // 
            this.tableLayoutPanel_new_pwd.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel_new_pwd.ColumnCount = 2;
            this.tableLayoutPanel_new_pwd.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_new_pwd.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_new_pwd.Controls.Add(this.textBox_new_pwd, 1, 0);
            this.tableLayoutPanel_new_pwd.Controls.Add(this.label_new_pwd, 0, 0);
            this.tableLayoutPanel_new_pwd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_new_pwd.Location = new System.Drawing.Point(4, 70);
            this.tableLayoutPanel_new_pwd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanel_new_pwd.Name = "tableLayoutPanel_new_pwd";
            this.tableLayoutPanel_new_pwd.RowCount = 1;
            this.tableLayoutPanel_new_pwd.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_new_pwd.Size = new System.Drawing.Size(486, 58);
            this.tableLayoutPanel_new_pwd.TabIndex = 1;
            // 
            // tableLayoutPanel_new_pwd2
            // 
            this.tableLayoutPanel_new_pwd2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel_new_pwd2.ColumnCount = 2;
            this.tableLayoutPanel_new_pwd2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_new_pwd2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_new_pwd2.Controls.Add(this.textBox_new_pwd2, 1, 0);
            this.tableLayoutPanel_new_pwd2.Controls.Add(this.label_new_pwd2, 0, 0);
            this.tableLayoutPanel_new_pwd2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_new_pwd2.Location = new System.Drawing.Point(4, 136);
            this.tableLayoutPanel_new_pwd2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanel_new_pwd2.Name = "tableLayoutPanel_new_pwd2";
            this.tableLayoutPanel_new_pwd2.RowCount = 1;
            this.tableLayoutPanel_new_pwd2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_new_pwd2.Size = new System.Drawing.Size(486, 58);
            this.tableLayoutPanel_new_pwd2.TabIndex = 2;
            // 
            // changePassword
            // 
            this.AcceptButton = this.button_OK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.CancelButton = this.button_Cancel;
            this.ClientSize = new System.Drawing.Size(494, 266);
            this.ControlBox = false;
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "changePassword";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "修改密码";
            this.TopMost = true;
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel_button.ResumeLayout(false);
            this.tableLayoutPanel_old_pwd.ResumeLayout(false);
            this.tableLayoutPanel_old_pwd.PerformLayout();
            this.tableLayoutPanel_new_pwd.ResumeLayout(false);
            this.tableLayoutPanel_new_pwd.PerformLayout();
            this.tableLayoutPanel_new_pwd2.ResumeLayout(false);
            this.tableLayoutPanel_new_pwd2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_OK;
        private System.Windows.Forms.TextBox textBox_old_pwd;
        private System.Windows.Forms.Label label_old_pwd;
        private System.Windows.Forms.TextBox textBox_new_pwd;
        private System.Windows.Forms.Label label_new_pwd;
        private System.Windows.Forms.TextBox textBox_new_pwd2;
        private System.Windows.Forms.Label label_new_pwd2;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_button;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_old_pwd;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_new_pwd;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_new_pwd2;
    }
}