// 增加数据 参数（表名，待增加的数据）
let addData = (formName, data) => {
    console.log(data);
    return wx.cloud.callFunction({
        name: 'addData',
        data: {
            formName,
            isAdmire: data.isAdmire,
            author: data.author,
            content: data.content,
            admireNum: data.admireNum,
            epid: data.epid

        }
    })
}
// 删除数据 参数（表名，待删除的单条数据的id）
let removeData = (formName, id) => {
    return wx.cloud.callFunction({
        name: 'removeData',
        data: {
            formName,
            id,
        }
    })
}
// 更新数据 参数（表名，待更新的数据的id，待更新的数据内容）
let updateData = (formName, id, data) => {
    return wx.cloud.callFunction({
        name: 'updateData',
        data: {
            formName,
            id,
            data: {
                isAdmire: data.isadmire,
                admireNum: data.admirenum
            }
        }
    })
}
// 查询数据 参数（表名）
let queryData = formName => {
    return wx.cloud.callFunction({
        name: 'queryData',
        data: {
            formName
        }
    })
}
// 查询单条数据 参数（表名，查询的单条数据对应的id）
let queryOneData = (formName, id) => {
    return wx.cloud.callFunction({
        name: 'queryOneData',
        data: {
            formName,
            id,
        }
    })
}
// 数据排序  参数（表名、依据、升序/降序）
let sortData = (formName, basis, sort) => {
    return wx.cloud.callFunction({
        name: 'sortData',
        data: {
            formName,
            basis,
            sort,
        }
    })
}
// 查询指定条数的数据 参数（表名， 指定的数据条数）
let queryLimitData = (formName, num) => {
    return wx.cloud.callFunction({
        name: 'queryLimitData',
        data: {
            formName,
            num
        }
    })
}
// 渲染my页面、增删改查、查询单条数据、数据排序、指定条数数据
module.exports = {
    addData,
    removeData,
    updateData,
    queryData,
    queryOneData,
    sortData,
    queryLimitData,
}