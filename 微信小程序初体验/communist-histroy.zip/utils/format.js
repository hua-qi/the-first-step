let format = (param) => {
  return param > 10 ? param : '0' + param;
};

let contentFormat = (param) =>{
  let content = [];
  let length = param.length;
  for (let i = 0; i < length; i++) {
    content[i] = param[i].content.replace(/<img/g, '<img style="width:100%;height:auto;display:block" ');
  }
  return content;
}

module.exports = {
  format,
  contentFormat
}