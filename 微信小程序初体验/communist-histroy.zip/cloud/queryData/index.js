// 云函数入口文件
const cloud = require('wx-server-sdk')

// 云函数初始化
cloud.init({
    env: cloud.DYNAMIC_CURRENT_ENV // 使用该常量，标志当前云函数环境
})

// 云函数入口函数
exports.main = async (event, context) => {
    let data = await cloud.database().collection(event.formName).get();
    
    return data;
}