// 引入 时间格式化 与 富文本格式化 公共函数
let { format, contentFormat } = require('../../utils/format');

Page({
  data: {
    list: [],

  },

  // 监听页面加载
  onLoad: function (options) {

    // 数据加载中提示
    wx.showLoading({
      title: '加载中...',
    });

    // 根据 options.date 判断是否是点击日历跳转至该页面
    let time = '';

    if (options.date) {

      // 由日历页面跳转
      time = options.date;

    } else {

      // 非由日历页面跳转
      let month = new Date().getMonth() + 1;
      let date = new Date().getDate();
      let monthFormat = format(month);
      let dateFormat = format(date);
      time = monthFormat + '-' + dateFormat;

    };

    // 根据时间请求接口
    wx.request({

      url: 'https://dangjian.myhope365.com/api/dangjian/djPartyHistory/list',
      method: "POST",
      data: {
        pageNum: 1,
        pageSize: 10,
        date: time
      },
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      success: res => {
        // let result = contentFormat(res.data.rows);
        this.setData({
          list: res.data.rows
        })

        // 数据加载完毕 隐藏加载提示
        wx.hideLoading();
      }
    })
  },

})