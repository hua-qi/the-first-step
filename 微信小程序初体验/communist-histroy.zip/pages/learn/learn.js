// 引入 时间格式化 公共函数
let { format } = require('../../utils/format');

Page({
  data: {
    time: '',
    // 从云存储 获取 图片
    timeSrc: 'cloud://huaqi-7g7xvl4ndcb0f138.6875-huaqi-7g7xvl4ndcb0f138-1305698207/Communist-history/assets/history.png',
    src: 'cloud://huaqi-7g7xvl4ndcb0f138.6875-huaqi-7g7xvl4ndcb0f138-1305698207/Communist-history/assets/memberOath.png'
  },

  // 页面监听加载

  onLoad: function (params) {
    // 数据加载中提示
    wx.showLoading({
      title: '加载中...',
    });

    // 获取当前时间并格式化
    let year = format(new Date().getFullYear());
    let month = format(new Date().getMonth() + 1);
    let date = format(new Date().getDate());
    let time = year + '-' + month + '-' + date;

    // 根据时间请求接口
    wx.request({

      url: 'https://dangjian.myhope365.com/api/dangjian/djArticle/list',
      method: "POST",
      data: {
        sendTime: time
      },
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      success: res => {
        this.setData({
          list: res.data.rows,
          time: time
        })
        // 数据加载完毕 隐藏加载提示
        wx.hideLoading();
      }
    })
  },

  // 携带参数页面跳转
  toDetail: function (params) {
    // console.log(params.currentTarget.dataset.articleid);
    let articleId = params.currentTarget.dataset.articleid;
    wx.reLaunch({
      url: '../detail/detail?articleId=' + articleId,
    });
  }
})