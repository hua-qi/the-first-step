// 引入日期处理公共函数
let { format } = require('../../utils/format');

Page({
  data: {
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 数据加载中提示
    wx.showLoading({
      title: '加载中...',
    });

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 数据加载完毕 隐藏加载提示
    wx.hideLoading();
  },

  onSelect: function (e) {
    
    // 由 日历的 点击事件 获取到 时间
    let month = e.detail.getMonth() + 1;
    let date = e.detail.getDate();
    // 进行格式化
    let monthFormat = format(month);
    let dateFormat = format(date);
    let time = monthFormat + '-' + dateFormat;
    // 跳转 页面传参
    wx.reLaunch({
      url: '../todayInHistory/todayInHistory?date=' + time,
    });
  }




})