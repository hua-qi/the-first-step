let { queryOneData, updateData, queryData, addData} = require('../../utils/common');
let formName = 'epidemic';
let collectionName = 'comments';
Page({
  data:{
    icon: 'cloud://huaqi-7g7xvl4ndcb0f138.6875-huaqi-7g7xvl4ndcb0f138-1305698207/Communist-history/assets/zan.png',
    iconActive: 'cloud://huaqi-7g7xvl4ndcb0f138.6875-huaqi-7g7xvl4ndcb0f138-1305698207/Communist-history/assets/zanActive.png'
  },
  onLoad:function (params) {
    // 数据加载中提示
    wx.showLoading({
      title: '加载中...',
    });

    // 获取 每日一学 文章id 或者 疫情 文章id
    let {articleId, id} = params;

    // 进行判断
    if (articleId) {
      // 此时是由 每日一学传递参数

      wx.request({
        url: `https://dangjian.myhope365.com/api/dangjian/djArticle/detail/${articleId}`,
        method: "GET",
        success: res => {
          console.log(res);
            this.setData({
              content: res.data.data.richTextNodes
            }) 
          }      
      });

      // 数据加载完毕 隐藏加载提示
      wx.hideLoading()

    } else {

      // 此时是由 疫情 传递参数

      queryOneData(formName,id)
      .then(res => {
        this.setData({
          detail: res.result.data
        })
        // 数据加载完毕 隐藏加载提示
        wx.hideLoading()
      })
      queryData(collectionName,id)
      .then(res => {
        this.setData({
          comments:res.result.data
        })
          // 数据加载完毕 隐藏加载提示
          wx.hideLoading()
      })
    };
  },

  admire: function (params) {
    let {id, epid ,isadmire ,admirenum} = params.currentTarget.dataset;
    if (isadmire == 0) {
      isadmire ++;
      admirenum--;
      updateData(collectionName,id,{
        isadmire,
        admirenum
      });
    } else {
      isadmire --;
      admirenum++;
      updateData(collectionName,id,{
        isadmire,
        admirenum
      });
    }
    queryData(collectionName,epid)
    .then(res => {
      this.setData({
        comments:res.result.data
      })
        // 数据加载完毕 隐藏加载提示
        wx.hideLoading()
    })
    
  },
  formSubmit:function (params) {
    let {isAdmire,author,content,epid,admireNum} = params.detail.value;
    isAdmire = parseInt(isAdmire);
    admireNum = parseInt(admireNum);
    addData(collectionName,{
      isAdmire,
      author,
      content,
      epid,
      admireNum
    }).then(res => {
      console.log(res)
    })
    queryData(collectionName,epid)
    .then(res => {
      this.setData({
        comments:res.result.data
      })
    })
   
  }


})