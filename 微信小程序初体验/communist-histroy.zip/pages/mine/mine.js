// 引入 查询数据 公共函数
let { queryData } = require('../../utils/common');

// 设置 集合 名称
let formName = 'epidemic';

Page({
  data: {
    list: [],
    // 从云存储获取图片
    src: 'cloud://huaqi-7g7xvl4ndcb0f138.6875-huaqi-7g7xvl4ndcb0f138-1305698207/Communist-history/assets/memberOath.png'
  },
  onLoad: function (params) {
    // 数据加载中提示
    wx.showLoading({
      title: '加载中...',
    });

    // 请求数据
    queryData(formName)
      .then(res => {
        this.setData({
          list: res.result.data
        })
        // 数据加载完毕 隐藏加载提示
        wx.hideLoading()
      });
  },

  // 页面跳转 携带参数
  toDetail: function (params) {
    // console.log(params.currentTarget.dataset.id);
    let id = params.currentTarget.dataset.id;
    wx.reLaunch({
      url: `../detail/detail?id=${id}`
    })
  }
})