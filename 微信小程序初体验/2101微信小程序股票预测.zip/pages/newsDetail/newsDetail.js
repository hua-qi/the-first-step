// 获取公共函数
const {queryOneData} = require('../../utils/common')
// 定义待操作的数据库表
let formName = 'newsList'
Page({
  data: {
    title: '',
    content: '',
    src: '',
  },
  onLoad(option) {
    // 设置加载中提示
    wx.showLoading({
      title: '加载中...',
    })
    // 调用公共函数 请求单条数据
   queryOneData(formName, option.id)
    .then( res => {
      this.setData({
        title: res.result.data.title,
        content: res.result.data.content ,
        src: res.result.data.src, 
      })
      // 数据加载完毕 隐藏加载提示
      wx.hideLoading()
    })
  },
})