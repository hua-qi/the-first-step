// 引入公共函数
const {
  addData,
  updateData
} = require('../../utils/common')
// 定义待操作的数据库表
let formName = 'my'
let id = 'b00064a7608fba1613f913d552ce8499'
let data = {
  pro_content: '  本产品主要投资于流动性资产、固定收益类资产、不动产类资产和其他金融资产，不投资于权益类资产。\n  本产品的基金财产在投资过程中可能面临各种风险，包括但不限于市场波动风险、信用风险、利率风险、流动性风险、操作风险、政策风险以及战争、自然灾害等不可抗力导致的基金财产损失，在本产品的管理人员遵守国家有关规定和合同条款约定的情况下，基金在运作过程中面临的风险由基金财产承担。产品在建仓初期，收益可能出现较大波动，属于正常情况。\n  所述预测结果及历史业绩仅供客户参考。'
}
Page({

  update() {
    updateData(formName, id, data)
    .then(res => {
      console.log('成功',res);
    })
    .catch(err => {
      console.log('失败', err);
    })
  },
  // add() {
  //   addData(formName, this.data)
  //   .then( res => {
  //     console.log('添加成功', res.result);
  //   })
  // }
})