// 调用公共函数
const {queryOneData, queryData} = require('../../utils/common')
// 定义待操作数据库表
let infor = 'informationList';
let my = 'my';
let id = 'b00064a7608fba1613f913d552ce8499'
let stockDetial = 'stockDetial'
Page({
  data: {
    name: '',
    percentage: '',
    term: '',
    list: [],
    my: {}
  },
  onLoad(option) {
    // 设置加载提示
    wx.showLoading({
      title: '加载中...',
    })
    // 调用公共函数 获取数据
    queryData(stockDetial).then(res => {
      this.setData({ list: res.result.data})
    })
    queryOneData(my, id).then(res => {
      console.log(res.result.data);
      this.setData({ my: res.result.data})
    })
    queryOneData(infor, option.id).then( res => {
      this.setData({
        name: res.result.data.name,
        percentage: res.result.data.percentage,
        term: res.result.data.term
      })
      wx.hideLoading()
    })
  }
})