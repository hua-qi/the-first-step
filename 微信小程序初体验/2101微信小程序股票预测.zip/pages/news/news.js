// 引入公共函数
const {
  queryData
} = require('../../utils/common')
// 定义待操作的数据库表
let newsSwiperImg = 'newsSwiperImg';
let newsList = 'newsList';
Page({
  // 数据先后是 轮播图数据列表、新闻内容列表
  data: {
    swiperImgData: [],
    newsListData: [],
  },
  // 界面打开时渲染
  onLoad() {
    // 数据加载中提示
    wx.showLoading({
      title: '加载中...',
    })
    // 使用 Promise 方法,调用封装的云函数方法
    queryData(newsSwiperImg)
      .then(res => {
        this.setData({
          swiperImgData: res.result.data
        })
      })
    queryData(newsList)
      .then(res => {
        this.setData({
          newsListData: res.result.data,
        })
        // 数据加载完毕 隐藏加载提示
        wx.hideLoading()
      })
  },
  // 携带id 跳转页面
  goToNews: function (e) {
    wx.navigateTo({
      url: '/pages/newsDetail/newsDetail?id=' + e.currentTarget.dataset.id,
    })
  },

})