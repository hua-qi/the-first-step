// 引入公共函数
const {
  queryData
} = require('../../utils/common');
// 定义待操作的数据库表
let informationList = 'informationList';
let stockSwiperImg = 'stockSwiperImg';
Page({
  data: {
    stockSwiperImg: [],
    informationList: [],
    loadingHidden: false
  },
  onLoad() {
    // 设置加载提示
    wx.showLoading({
      title: '加载中...',
    })
    // 调用公共函数 请求数据
    queryData(stockSwiperImg)
      .then(res => {
        this.setData({
          stockSwiperImg: res.result.data
        })
      })
      queryData(informationList)
      .then(res => {
        this.setData({
          informationList: res.result.data,
          loadingHidden: true
        })
        // 数据加载完毕 隐藏加载提示
        wx.hideLoading()
      })
  },
  goToDetail: function (e) {
    // 获取携带data-id的数据
    wx.navigateTo({
      url: '/pages/stockDetail/stockDetial?id=' + e.currentTarget.dataset.id,
    })
  },
})