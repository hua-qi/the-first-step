// 引入 eccharts.js
import * as echarts from '../../ec-canvas/echarts'
// 引入common.js
let {
  queryData
} = require('../../utils/common')
// 定义待操作数据库表
let formName = 'chartSort';
// 设置图表格式 
let initChart = (canvas, width, height, dpr, chartSort) => {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio: dpr
  })
  canvas.setChart(chart);
  let option = {
    title: {
      text: chartSort.title.text,
      textStyle: {
        color: '#1296db',
      }
    },
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      left: 'right',
      top: '20rpx',
    },
    grid: {
      left: '5%',
      right: '16%',
      bottom: '10%',
      containLabel: true
    },
    xAxis: {
      name: '2021年',
      nameLocation: 'end',
      type: 'category',
      boundaryGap: false,
      data: [
        "03-01", "03-02", "03-03", "03-04", "03-05", "03-06", "03-07", "03-08", "03-09", "03-10", "03-11", "03-12", "03-13", "03-14", "03-15", "03-16", "03-17", "03-18", "03-19", "03-20", "03-21", "03-22", "03-23", "03-24", "03-25", "03-26", "03-27", "03-28", "03-29", "03-30", "03-31", "04-01", "04-02", "04-03", "04-04", "04-05", "04-06", "04-07", "04-08", "04-09", "04-10", "04-11", "04-12", "04-13", "04-14", "04-15", "04-16", "04-17", "04-18", "04-19", "04-20", "04-21", "04-22", "04-23", "04-24", "04-25", "04-26", "04-27", "04-28", "04-29", "04-30"
      ],
      splitNumber: 60,
      axisTick: {
        show: true,
        interval: 0 //显示所有刻度
      },
      axisLabel: {
        interval: 2, //显示所有刻度标签
        rotate: 45,
        // fontSize = 12
      }
    },
    yAxis: {
      offset: 10,
      name: '单位量',
      nameLocation: 'end',
      type: 'value',
      splitNumber: chartSort.yAxis.splitNumber,
      min: chartSort.yAxis.min,
      max: chartSort.yAxis.max,
      // minInterval: 0.00,
      // 坐标中刻度标签的相关设置
      axisLabel: {
        // 内容格式器 刻度为小数点后两位
        formatter: (value, index) => {
          return value.toFixed(2)
        }
      }
    },
    series: [{
        name: '预测走势',
        type: 'line',
        data: chartSort.forecast.data,
      },
      {
        name: '实际走势',
        type: 'line',
        data: chartSort.actual.data,
      }
    ]
  }
  chart.setOption(option);
  return chart;
}
Page({
  data: {
    ec: {
      onInit: initChart
    },
    chartSort: []
  },
  onLoad() {
    // 数据加载中提示
    wx.showLoading({
      title: '加载中...',
    })
    // 请求数据
    queryData(formName)
      .then(res => {
        this.setData({
          chartSort: res.result.data
        })
        // 数据加载完毕 隐藏加载提示
        wx.hideLoading()
      })
  }
})