App({
  // 该方法，小程序启动即执行
  onLaunch: function() {
    // console.log('小程序已启动');
    //云开发初始化
    wx.cloud.init({
      env:"huaqi-7g7xvl4ndcb0f138"  //云开发环境ID
    })
  }
})